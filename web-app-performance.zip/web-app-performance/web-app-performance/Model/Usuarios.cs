﻿namespace web_app_performance.Model
{
    public class Usuarios
    {
        public int Id { 
            get; 
            set; 
        }

        public string Nome {
            get;
            set;
        }

        public string Email
        {
            get;
            set;
        }
    }
}
